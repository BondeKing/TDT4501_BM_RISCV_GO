

// max size of a collum is 10 here, sicne this is requierd for c to know this.
void matrixmultiply(int a[][10], int b[][10], int result[][10], int aVertSize, int aHorSize, int bVertSize, int bHorSize){

    if (aVertSize != bHorSize || aHorSize != bVertSize){
        return;
    }

    for(int i=0; i<aVertSize; i++){
        
        for(int j=0; j<bHorSize; j++){
            result[i][j] = 0;
        }
    }

    int s = 0;

    for(int ia=0; ia<aVertSize; ia++){

        for(int ib=0; ib<bHorSize; ib++){

            s = 0;
            for(int j=0; j<aHorSize; j++){
                s += a[ia][j] * b[j][ib];
            }
            result[ia][ib] = s;
        }
    }

    return;

}

void testmatrixmultiply(){

    int result[10][10];

    int test1[][10] = {{1, 2, 3}, {4, 5, 6}};
    int test2[][10] = {{1, 2}, {3, 4}, {5, 6}};

    matrixmultiply(test1, test2, result, 2, 3, 3, 2);

    // not freeing any memory here on purpose

    return;
}

int main() {
    
    int runs = 50000;

    for(int i=0; i<runs; i++){
        testmatrixmultiply();
    }

    return 0;
}