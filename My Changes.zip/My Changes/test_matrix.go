package main

func main() {

	runs := 50000

	for i:=0; i<runs; i++ {
		testmatrixmulitply()
	}
	
	return
}


/*

a =
{0,0,0},
{0,0,0}

means len(a) = 2 and len(a[0]) = 3 
*/
func matrixmultiply(a, b [][]int, aVertSize, aHorSize, bVertSize, bHorSize int) [][]int {

	if aVertSize != bHorSize || aHorSize != bVertSize{
		return nil
	}

	c := make([][]int, aVertSize)
	for i:=0; i<aVertSize; i++ {
		c[i] = make([]int, bHorSize)
	}
	s := 0
	
	for ia:=0; ia<aVertSize; ia++ {
		
		for ib:=0; ib<bHorSize; ib++ {
			s = 0
			for j:=0; j<aHorSize; j++ {
				
				s += a[ia][j] * b[j][ib]
				
			}
			
			c[ia][ib] = s

		}
	}

	return c

}

func testmatrixmulitply() bool {

	test1 := [][]int{
		[]int{1,2,3},
		[]int{4,5,6},
	}

	test2 := [][]int{
		[]int{1,2},
		[]int{3,4},
		[]int{5,6},
	}
	//test3 := {{1,2},{3,4}}
	//test4 := {{1,2,3},{4,5,6},{7,8,9}}
	//test5 := {{0,0,0},{0,0,0}}

	result1 := matrixmultiply(test1, test2, 2, 3, 3, 2)	

	if (result1 == nil) {
		return false
	}
	

	return true

}
